package com.apkmaster.pro.ui

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.apkmaster.pro.R

/** The 10 main sections. [implemented] stays false until a real feature backs the screen. */
enum class Section(@StringRes val title: Int, val icon: ImageVector, val implemented: Boolean = false) {
    Home(R.string.sec_home, Icons.Default.Home, true),
    Create(R.string.sec_create, Icons.Default.Add),
    Modify(R.string.sec_modify, Icons.Default.Edit),
    Import(R.string.sec_import, Icons.Default.Share, true),
    Sdk(R.string.sec_sdk, Icons.Default.Build),
    Ai(R.string.sec_ai, Icons.Default.Star),
    Editor(R.string.sec_editor, Icons.Default.Create),
    Projects(R.string.sec_projects, Icons.Default.List),
    Builder(R.string.sec_builder, Icons.Default.PlayArrow),
    Settings(R.string.sec_settings, Icons.Default.Settings)
}
