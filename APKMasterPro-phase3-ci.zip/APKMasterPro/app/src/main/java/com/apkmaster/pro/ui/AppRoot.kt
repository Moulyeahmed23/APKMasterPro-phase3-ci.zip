package com.apkmaster.pro.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.apkmaster.pro.R
import com.apkmaster.pro.ui.theme.Gold
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    var current by rememberSaveable { mutableStateOf(Section.Home) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(stringResource(R.string.app_name), color = Gold,
                    style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(24.dp))
                Section.values().forEach { s ->
                    NavigationDrawerItem(
                        icon = { Icon(s.icon, null) },
                        label = { Text(stringResource(s.title)) },
                        selected = s == current,
                        onClick = { current = s; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(current.title)) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Default.Menu, stringResource(R.string.menu))
                        }
                    }
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (current) {
                    Section.Home -> HomeScreen { current = it }
                    Section.Import -> ImportScreen()
                    else -> SectionScreen(current)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onOpen: (Section) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.home_welcome), style = MaterialTheme.typography.bodyLarge) }
        items(Section.values().filter { it != Section.Home }) { s ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(s) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(s.icon, null, tint = Gold)
                    Column {
                        Text(stringResource(s.title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(if (s.implemented) R.string.status_ready else R.string.status_not_ready),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionScreen(s: Section) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(s.icon, null, tint = Gold, modifier = Modifier.size(48.dp))
        Text(stringResource(s.title), style = MaterialTheme.typography.headlineSmall)
        Text("${stringResource(R.string.status_label)}: " +
            stringResource(if (s.implemented) R.string.status_ready else R.string.status_not_ready))
    }
}
