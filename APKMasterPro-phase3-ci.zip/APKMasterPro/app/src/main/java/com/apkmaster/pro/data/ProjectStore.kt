package com.apkmaster.pro.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.apkmaster.pro.R
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream

data class ProjectFile(val file: File, val rel: String, val size: Long, val binary: Boolean)

/** Projects live in private app storage: filesDir/projects/<name>/. Imported files are never executed. */
class ProjectStore(private val ctx: Context) {
    val root = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val maxTotal = 500L * 1024 * 1024
    private val maxEntries = 20_000
    private val binaryExt = setOf("apk", "dex", "so", "jar", "sh", "exe", "bat", "bin", "elf")

    fun projects(): List<File> =
        root.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: emptyList()

    fun sanitize(s: String): String =
        s.trim().replace(Regex("[^\\p{L}\\p{N}_. -]"), "_").trim('.', ' ').take(64)

    fun create(name: String): File? {
        val n = sanitize(name)
        if (n.isEmpty()) return null
        return File(root, n).also { it.mkdirs() }
    }

    private fun inside(parent: File, child: File) =
        child.canonicalPath.startsWith(parent.canonicalPath + File.separator)

    fun deleteProject(name: String): Boolean {
        val f = File(root, name)
        return inside(root, f) && f.deleteRecursively()
    }

    fun deleteFile(project: File, f: File): Boolean = inside(project, f) && f.delete()

    fun files(project: File): List<ProjectFile> =
        project.walkTopDown().filter { it.isFile }.take(500).map {
            ProjectFile(it, it.relativeTo(project).path, it.length(), it.extension.lowercase() in binaryExt)
        }.toList()

    private fun displayName(uri: Uri): String =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: uri.lastPathSegment ?: "file"

    private fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        var i = 1
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
            i++
        }
        return f
    }

    fun importUri(project: File, uri: Uri): String {
        val name = sanitize(displayName(uri)).ifEmpty { "file" }
        return try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open")
            input.use {
                if (name.endsWith(".zip", true)) {
                    val dir = unique(project, name.dropLast(4).ifEmpty { "archive" })
                    dir.mkdirs()
                    val (n, skipped) = extractZip(it, dir)
                    ctx.getString(R.string.log_extracted, n, name) +
                        if (skipped > 0) "\n" + ctx.getString(R.string.log_skipped, skipped) else ""
                } else {
                    val dest = unique(project, name)
                    dest.outputStream().use { o -> it.copyTo(o) }
                    ctx.getString(R.string.log_imported, dest.name)
                }
            }
        } catch (e: Exception) {
            ctx.getString(R.string.log_failed, name, e.message ?: e.javaClass.simpleName)
        }
    }

    /** Extracts with zip-slip protection and entry/size limits. Returns (files, skippedUnsafe). */
    private fun extractZip(input: InputStream, dest: File): Pair<Int, Int> {
        val destPath = dest.canonicalPath + File.separator
        var count = 0
        var skipped = 0
        var total = 0L
        ZipInputStream(input.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(destPath)) {
                    skipped++
                } else if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    if (++count > maxEntries) throw IOException("too many entries")
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o ->
                        val buf = ByteArray(8192)
                        var r: Int
                        while (z.read(buf).also { r = it } > 0) {
                            total += r
                            if (total > maxTotal) throw IOException("archive too large")
                            o.write(buf, 0, r)
                        }
                    }
                }
                e = z.nextEntry
            }
        }
        return count to skipped
    }

    fun importTree(project: File, tree: Uri): String {
        val doc = DocumentFile.fromTreeUri(ctx, tree)
            ?: return ctx.getString(R.string.log_failed, tree.toString(), "invalid folder")
        val name = sanitize(doc.name ?: "folder").ifEmpty { "folder" }
        val dir = unique(project, name)
        dir.mkdirs()
        var n = 0
        var total = 0L
        fun walk(d: DocumentFile, out: File, depth: Int) {
            if (depth > 20) return
            for (c in d.listFiles()) {
                val raw = c.name ?: continue
                val cn = sanitize(raw)
                if (cn.isEmpty()) continue
                if (c.isDirectory) {
                    val sub = File(out, cn)
                    sub.mkdirs()
                    walk(c, sub, depth + 1)
                } else if (c.isFile) {
                    if (++n > maxEntries) throw IOException("too many files")
                    val input = ctx.contentResolver.openInputStream(c.uri) ?: continue
                    input.use { i ->
                        File(out, cn).outputStream().use { o ->
                            val buf = ByteArray(8192)
                            var r: Int
                            while (i.read(buf).also { r = it } > 0) {
                                total += r
                                if (total > maxTotal) throw IOException("folder too large")
                                o.write(buf, 0, r)
                            }
                        }
                    }
                }
            }
        }
        return try {
            walk(doc, dir, 0)
            ctx.getString(R.string.log_folder, name, n)
        } catch (e: Exception) {
            ctx.getString(R.string.log_failed, name, e.message ?: e.javaClass.simpleName)
        }
    }
}
