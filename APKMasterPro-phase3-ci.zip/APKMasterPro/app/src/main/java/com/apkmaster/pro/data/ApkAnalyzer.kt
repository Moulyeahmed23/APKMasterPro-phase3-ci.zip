package com.apkmaster.pro.data

import android.content.Context
import java.io.File
import java.util.zip.ZipFile

data class ApkInfo(
    val label: String, val pkg: String, val versionName: String?, val versionCode: Long,
    val minSdk: Int, val webFiles: Int, val images: Int, val hasCompiledResources: Boolean
)

/** Read-only inspection. The APK is never installed or executed. */
object ApkAnalyzer {
    private val web = setOf("html", "htm", "css", "js", "json")
    private val img = setOf("png", "jpg", "jpeg", "webp")

    fun analyze(ctx: Context, f: File): ApkInfo? {
        val pm = ctx.packageManager
        val pi = pm.getPackageArchiveInfo(f.absolutePath, 0) ?: return null
        val ai = pi.applicationInfo ?: return null
        ai.sourceDir = f.absolutePath
        ai.publicSourceDir = f.absolutePath
        var w = 0
        var im = 0
        var arsc = false
        try {
            ZipFile(f).use { z ->
                for (e in z.entries()) {
                    if (e.isDirectory) continue
                    val n = e.name.lowercase()
                    val ext = n.substringAfterLast('.', "")
                    if (n == "resources.arsc") arsc = true
                    if (n.startsWith("assets/") && ext in web) w++
                    if ((n.startsWith("res/") || n.startsWith("assets/")) && ext in img) im++
                }
            }
        } catch (_: Exception) { }
        return ApkInfo(ai.loadLabel(pm).toString(), pi.packageName, pi.versionName, pi.longVersionCode,
            ai.minSdkVersion, w, im, arsc)
    }
}
