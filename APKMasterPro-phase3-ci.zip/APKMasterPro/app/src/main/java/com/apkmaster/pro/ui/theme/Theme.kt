package com.apkmaster.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1030)
val NavySurface = Color(0xFF141A45)
val Purple = Color(0xFF7C4DFF)
val Gold = Color(0xFFFFC857)

private val Scheme = darkColorScheme(
    primary = Purple, onPrimary = Color.White,
    secondary = Gold, onSecondary = Navy,
    background = Navy, onBackground = Color(0xFFEDEBFF),
    surface = NavySurface, onSurface = Color(0xFFEDEBFF),
    surfaceVariant = Color(0xFF1D2563), onSurfaceVariant = Color(0xFFC9C6E8)
)

// Dark is the default and only theme in phase 1.
@Composable
fun ApkMasterTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
