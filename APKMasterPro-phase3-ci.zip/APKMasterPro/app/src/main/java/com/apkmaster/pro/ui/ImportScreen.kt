package com.apkmaster.pro.ui

import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.apkmaster.pro.R
import com.apkmaster.pro.data.*
import com.apkmaster.pro.ui.theme.Gold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ImportScreen() {
    val ctx = LocalContext.current
    val store = remember { ProjectStore(ctx) }
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var newName by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf(listOf<String>()) }
    var apk by remember { mutableStateOf(mapOf<String, ApkInfo?>()) }

    val projects = remember(tick) { store.projects() }
    val files = remember(selected, tick) {
        selected?.let { store.files(File(store.root, it)) } ?: emptyList()
    }

    fun runImport(p: String, job: (File) -> List<String>) {
        busy = true
        scope.launch {
            val msgs = withContext(Dispatchers.IO) { job(File(store.root, p)) }
            log = (msgs + log).take(30)
            busy = false
            tick++
        }
    }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val p = selected
        if (p != null && uris.isNotEmpty()) runImport(p) { dir -> uris.map { store.importUri(dir, it) } }
    }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val p = selected
        if (p != null && uri != null) runImport(p) { dir -> listOf(store.importTree(dir, uri)) }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.imp_intro), style = MaterialTheme.typography.bodyMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), singleLine = true,
                    label = { Text(stringResource(R.string.imp_new_project)) })
                Button(onClick = {
                    store.create(newName)?.let { selected = it.name; newName = ""; tick++ }
                }) { Text(stringResource(R.string.imp_create)) }
            }
        }
        item { Text(stringResource(R.string.imp_projects), style = MaterialTheme.typography.titleMedium, color = Gold) }
        if (projects.isEmpty()) item { Text(stringResource(R.string.imp_none)) }
        items(projects, key = { it.name }) { p ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
                containerColor = if (p.name == selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                else MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(start = 16.dp, end = 8.dp).fillMaxWidth(),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(p.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    TextButton(onClick = { selected = p.name }) { Text(stringResource(R.string.imp_open)) }
                    TextButton(onClick = {
                        store.deleteProject(p.name)
                        if (selected == p.name) selected = null
                        tick++
                    }) { Text(stringResource(R.string.imp_delete)) }
                }
            }
        }
        val sel = selected
        if (sel != null) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.imp_selected, sel), color = Gold)
                    Button(onClick = { pickFiles.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.imp_pick_files))
                    }
                    OutlinedButton(onClick = { pickTree.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.imp_pick_folder))
                    }
                    if (busy) { Text(stringResource(R.string.imp_busy)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                }
            }
            if (log.isNotEmpty()) {
                item { Text(stringResource(R.string.imp_log), style = MaterialTheme.typography.titleMedium, color = Gold) }
                items(log) { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
            item { Text(stringResource(R.string.imp_files), style = MaterialTheme.typography.titleMedium, color = Gold) }
            if (files.isEmpty()) item { Text(stringResource(R.string.imp_empty)) }
            items(files, key = { it.rel }) { pf ->
                Column(Modifier.fillMaxWidth()) {
                    Text(pf.rel, style = MaterialTheme.typography.bodyMedium)
                    Text(Formatter.formatShortFileSize(ctx, pf.size), style = MaterialTheme.typography.bodySmall)
                    if (pf.binary) Text(stringResource(R.string.warn_binary), style = MaterialTheme.typography.bodySmall, color = Gold)
                    Row {
                        if (pf.file.extension.equals("apk", true)) TextButton(onClick = {
                            scope.launch {
                                val info = withContext(Dispatchers.IO) { ApkAnalyzer.analyze(ctx, pf.file) }
                                apk = apk + (pf.rel to info)
                            }
                        }) { Text(stringResource(R.string.imp_analyze)) }
                        TextButton(onClick = { store.deleteFile(File(store.root, sel), pf.file); tick++ }) {
                            Text(stringResource(R.string.imp_delete))
                        }
                    }
                    if (apk.containsKey(pf.rel)) ApkCard(apk[pf.rel])
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun ApkCard(i: ApkInfo?) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (i == null) { Text(stringResource(R.string.apk_unreadable)); return@Column }
            val yn = stringResource(if (i.hasCompiledResources) R.string.yes else R.string.no)
            Text(stringResource(R.string.apk_name, i.label))
            Text(stringResource(R.string.apk_pkg, i.pkg))
            Text(stringResource(R.string.apk_version, i.versionName ?: "?", i.versionCode))
            Text(stringResource(R.string.apk_minsdk, i.minSdk))
            Text(stringResource(R.string.apk_web, i.webFiles))
            Text(stringResource(R.string.apk_images, i.images))
            Text(stringResource(R.string.apk_arsc, yn))
            Text(stringResource(R.string.apk_note), style = MaterialTheme.typography.bodySmall, color = Gold)
        }
    }
}
