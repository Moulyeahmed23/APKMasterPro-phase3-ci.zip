package com.apkmaster.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.apkmaster.pro.ui.AppRoot
import com.apkmaster.pro.ui.theme.ApkMasterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApkMasterTheme { AppRoot() } }
    }
}
