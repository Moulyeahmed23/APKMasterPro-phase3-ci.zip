# APK Master Pro — Phase 3
Open this folder in Android Studio (JDK 17). It syncs Gradle and generates the wrapper.
Build: Build > Build APK(s)  or  ./gradlew assembleDebug
Status: skeleton, navigation, project import (files, ZIP, folders, APK analysis). Not yet built/tested in the authoring environment.

## Build the APK without a PC
1. Upload this project to a GitHub repository (keep the .github folder).
2. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push).
3. When it finishes, download the artifact "APKMasterPro-debug" (a zip containing app-debug.apk) and install it.
If the build fails, copy the error from the log and send it back for a fix.
